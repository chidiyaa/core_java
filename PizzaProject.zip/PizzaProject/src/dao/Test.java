package dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

import beans.Customer;
import beans.Order;

//import com.capgemini.doctors.exceptions.QASException;

import exception.PizzaException;

public class Test {
    private static DAOInterface daoimpl;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		daoimpl= new DAOImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		daoimpl=null;
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@org.junit.Test(expected=NullPointerException.class)
	public void testPlaceOrder() {
		try 
		{
			
			daoimpl.placeOrder(null,null);
		}
		catch (PizzaException e) {
			
			System.out.println("Null Pointer Exception");
		}
	}
    
	@org.junit.Test
	public void testPlaceOrder1() {
		try 
		{
			Customer customer = new Customer("sravani","vizag","9010859483");
			Order pizzaOrder=new Order(0,0,0);
			daoimpl.placeOrder(customer,pizzaOrder);
		}
		catch (PizzaException e) {
			
			System.out.println("Null Pointer Exception");
		}
	}
	
	@org.junit.Test
	public void testPlaceOrder2() {
		try 
		{
			Customer customer = new Customer(null,"vizag","9010859483");
			Order pizzaOrder=new Order(0,0,0);
			daoimpl.placeOrder(customer,pizzaOrder);
		}
		catch (PizzaException e) {
			
			System.out.println("Null Pointer Exception");
		}
	}
	
	@org.junit.Test(expected=NullPointerException.class)
	public void testGetOrderDetails() {
	try 
		{

		daoimpl.getOrderDetails(-1000);

		} 
	    catch (PizzaException e) {
		
		System.out.println("Null Pointer Exception");
	   }
		
	}
	
	
	@org.junit.Test
	public void testGetOrderDetails1() {
	try 
		{
         Order pizzaOrder =  daoimpl.getOrderDetails(1000);
        		
		boolean obtained=false;
		boolean expected=true ;
         if(pizzaOrder.getCustId()>0)
			 obtained=true ;
       assertEquals(expected, obtained);
		} 
	    catch (PizzaException e) {
		
		System.out.println("Null Pointer Exception");
	   }
		
	}
}


