package dao;
import java.util.HashMap;
import java.util.Map;
import beans.Customer;
import beans.Order;
import exception.PizzaException;
public class DAOImpl implements DAOInterface
{
	//HashMapCreation for customer and pizza
    Map<Integer,Customer>  customers=new HashMap<Integer,Customer>();
    Map<Integer,Order> orders = new HashMap<Integer,Order>();
   
    //Randomnumber generation for customer
    public int generatecustomerId()
    {
    	double randomNumber = Math.random() ;
		
		return (int) (randomNumber * 10000) ;
    }
    
    //Randomnumber generation for orderId
    public int generateorderId()
    {
    	double randomNumber = Math.random() ;
		
		return (int) (randomNumber * 10000) ;
    }
    @Override
	public int placeOrder(Customer customer, Order pizzaorder) throws PizzaException {
    	
    	
    	if((customer==null) || (pizzaorder==null))
			throw new NullPointerException() ;
    	
    	//generating customerId
    	customer.setCustId(generatecustomerId());
    	customers.put(customer.getCustId(),customer);
    	
    	//generating pizzaorderId
    	pizzaorder.setOrderId(generateorderId());
    	//setting customerId to pizzaorder
    	pizzaorder.setCustId(customer.getCustId());
    	
    	orders.put(pizzaorder.getOrderId(), pizzaorder);
        return   pizzaorder.getOrderId();
	}

	@Override
	public Order getOrderDetails(int orderId) throws PizzaException {
		if(orderId < 0)
			throw new NullPointerException() ;
		Order pizzaorder=null;
		
	    pizzaorder = orders.get(orderId);
	    
	    if(pizzaorder==null)
			throw new PizzaException("\n\tSorry, orderSId : "+orderId+" doesnot exist") ;
	    
		return pizzaorder;
	}

}
