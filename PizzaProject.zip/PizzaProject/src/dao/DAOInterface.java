package dao;

import beans.Customer;
import beans.Order;
import exception.PizzaException;

public interface DAOInterface {

	public int placeOrder(Customer customer,Order pizzaorder) throws PizzaException;
	
	public Order getOrderDetails(int orderId) throws PizzaException;
	
}
