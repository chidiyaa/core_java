package services;

import beans.Customer;
import beans.Order;
import dao.DAOImpl;
import dao.DAOInterface;
import exception.PizzaException;

public class ServiceImpl implements ServiceInterface{
   private DAOInterface daoimpl;
   
   
	public ServiceImpl() {
	      daoimpl=new DAOImpl();
}

	@Override
	public int placeOrder(Customer customer, Order pizzaorder) throws PizzaException {
		int orderId=0;
		if(isValidNo(customer)==true)
		orderId=daoimpl.placeOrder(customer, pizzaorder);
		return orderId;
	}

	
	@Override
	public Order getOrderDetails(int orderId) throws PizzaException {
		Order pizzaorder=null;
		pizzaorder = daoimpl.getOrderDetails(orderId);
		return pizzaorder;
	}
	
    
	
	//phonenumber validationSS
	private boolean isValidNo(Customer customer) {
		if(customer.getNo().length()==10)
			return true;
		else
		return false;
	}


}
