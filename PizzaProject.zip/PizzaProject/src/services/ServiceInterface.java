package services;

import beans.Customer;
import beans.Order;
import exception.PizzaException;

public interface ServiceInterface {

    public int placeOrder(Customer customer,Order pizzaorder) throws PizzaException;
	
	public Order getOrderDetails(int orderId) throws PizzaException;
}
