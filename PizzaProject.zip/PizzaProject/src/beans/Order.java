package beans;

public class Order {

	private int orderId;
	private int custId;
	private int totalPrice;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Order(int orderId, int custId, int totalPrice) {
		super();
		this.orderId = orderId;
		this.custId = custId;
		this.totalPrice = totalPrice;
	}
	public Order() {
		super();
	}
	public Order(int orderId) {
		super();
		this.orderId = orderId;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", custId=" + custId + ", totalPrice=" + totalPrice + "]";
	}
	
}
