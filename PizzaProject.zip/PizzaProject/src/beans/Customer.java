package beans;

public class Customer {
	private int custId;
	private String name;
	private String address;
	private String no;
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public Customer(int custId, String name, String address, String no) {
		super();
		this.custId = custId;
		this.name = name;
		this.address = address;
		this.no = no;
	}
	public Customer() {
		super();
	}
	public Customer(int custId) {
		super();
		this.custId = custId;
	}
	public Customer(String name, String address, String no) {
		super();
		this.name = name;
		this.address = address;
		this.no = no;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", address=" + address + ", no=" + no + "]";
	}
	
	
}
