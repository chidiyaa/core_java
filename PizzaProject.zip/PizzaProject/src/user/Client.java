package user;

import java.time.LocalDate;
import java.util.Scanner;

import beans.Customer;
import beans.Order;
import exception.PizzaException;

//import com.capgemini.doctors.ui.Client;

import services.ServiceImpl;
import services.ServiceInterface;

public class Client
{
private ServiceInterface serviceimpl;
public Client()
{
	serviceimpl = new ServiceImpl();
}

public void menu() 
{
	
	Scanner console = new Scanner(System.in) ;
	System.out.println("enter your choice");
	System.out.println("1)place order");
	System.out.println("2)get order");
	System.out.println("3)ext");
	int basepizzaprice=350;
    int totalprize=0;
	Order pizzaorder=new Order();
	Customer customer =new Customer();
	System.out.print("\n\nEnter the choice : ");
	int choice = console.nextInt() ;
	
	switch(choice)
	{
	
	case 1 : 
		     System.out.println("\nEnter Cutomer details:");
		     System.out.println("------------------------");
		      System.out.println("\nEnter name:");
	          String name = console.next();
	
	          System.out.println("\nEnter address:");
	          String address=console.next();
	
	         System.out.println("\nEnter number:");
	         String  no = console.next();
	
	
	         System.out.println("\nSelect the List of Toppins");
	         System.out.println("Pizza Toppings\tRupees");
	         System.out.println("1.Capsicum\t30");
	         System.out.println("2.Mushroom\t50");
	         System.out.println("3.Jalapeno\t70");
	         System.out.println("4.Panner\t85");
	         System.out.println("\nbaseprize for pizza is Rs.350");
	         
             System.out.println("\nenter topping:");
           int topping= console.nextInt();
           switch(topping)
          {
              case 1:
    	             totalprize= basepizzaprice +30;
    	      break;
              case 2:
    	             totalprize= basepizzaprice +50;
    	      break;
              case 3:
    	            totalprize= basepizzaprice +70;
    	      break;
              case 4:
    	            totalprize= basepizzaprice +85;
    	      break;
    	      default:
    		  System.out.println("invalid option");
    		  break;
    	}
           
       customer.setName(name);
       customer.setAddress(address);
       customer.setNo(no);
       
       pizzaorder.setTotalPrice(totalprize);
       
		try {
			int orderId=serviceimpl.placeOrder(customer, pizzaorder);
	        System.out.println("OrderID     :"  + pizzaorder.getOrderId());
	        System.out.println("orderdate   : " + LocalDate.now());
		    System.out.println("totalprice  :"  + pizzaorder.getTotalPrice());
		} catch (PizzaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     
   break;
	case 2 :
		System.out.println("\nDisplay Details");
		System.out.println("------------------");
		System.out.println("\nEnter orderId");
		int orderId= console.nextInt();
		
		try
		{
			pizzaorder = serviceimpl.getOrderDetails(orderId);
			
			System.out.println("Order Id     : "+pizzaorder.getOrderId()) ;
			System.out.println("Customer Id  : "+pizzaorder.getCustId());
			System.out.println("Total Price  : "+pizzaorder.getTotalPrice());
			
			
		}
		catch (PizzaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		break;
		
	case 3 :
		//exit from the application
		
		System.out.println("\n\tApplication terminated successfully");
		System.exit(0) ;
		
		break ;	
		
default:
	 System.out.println("\nInvalid Choice");
	 break;
		}	
}


public static void main(String[] args) 
{
	
	Client client = new Client() ;
	
	while(true)
		client.menu();
}
}